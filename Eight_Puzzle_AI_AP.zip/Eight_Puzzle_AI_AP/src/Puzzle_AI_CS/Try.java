package Puzzle_AI_CS;

public class Try {

}
